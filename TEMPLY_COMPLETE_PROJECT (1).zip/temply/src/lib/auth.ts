import { createClient } from '@/lib/supabase/server';
export async function requireAdmin() {
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user) return {user:null,ok:false};
 const {data}=await supabase.from('admin_users').select('user_id').eq('user_id',user.id).maybeSingle();
 return {user,ok:!!data};
}
