import crypto from 'crypto';
export function hmac(value:string,secret:string){return crypto.createHmac('sha256',secret).update(value).digest('hex')}
export function safeEqual(a:string,b:string){const x=Buffer.from(a);const y=Buffer.from(b);return x.length===y.length && crypto.timingSafeEqual(x,y)}
