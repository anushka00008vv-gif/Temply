import './globals.css';
import type { Metadata } from 'next';
export const metadata:Metadata={title:'TEMPLY — Better conversations begin here',description:'Practical dating, communication and relationship guides for more thoughtful connections.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
