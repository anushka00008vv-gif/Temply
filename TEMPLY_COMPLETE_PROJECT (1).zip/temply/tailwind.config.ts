import type { Config } from 'tailwindcss';
export default { content:['./src/**/*.{js,ts,jsx,tsx,mdx}'], theme:{extend:{colors:{paper:'#F5F0E7',ink:'#201D1B',rose:'#A43D48',muted:'#77716A'},fontFamily:{serif:['Georgia','serif']}}}, plugins:[] } satisfies Config;
