# TEMPLY — digital product storefront

A Next.js 15 + Supabase + Razorpay starter for the TEMPLY digital publishing store.

## Honest implementation status

Included in this project:
- Responsive editorial storefront, product detail pages and six-product catalogue.
- Razorpay server-side order creation, checkout signature verification and webhook signature verification.
- Supabase schema for products, customers, orders, payments, downloads, testimonials, coupons, leads, settings, popup events and analytics events.
- Paid-order-gated download token endpoint with 24-hour expiry and private Supabase Storage signed URL.
- Admin authentication gate backed by Supabase Auth and an explicit `admin_users` allowlist.
- Admin starter views for orders, products, reviews, downloads and popup/settings configuration.
- Customer order lookup page that checks order ID + checkout email before issuing a short-lived download token.
- Admin sign-out route.
- Free guide lead capture endpoint (email provider automation is not yet wired).
- Six complete starter PDFs in `public/downloads/`.

Not yet complete / requires owner configuration or further implementation:
- The included admin product/review/popup screens are read-only starter views; full CRUD visual editing, coupon application, full analytics charts, testimonial submission workflow and homepage CMS editor still need implementation.
- The lead form stores consented leads, but transactional/marketing email sending and unsubscribe endpoint need a provider account and implementation.
- A customer order lookup UI and automatic post-payment email with a one-click download link are not yet wired.
- Purchase notification display component is not enabled on the storefront. The database schema and admin configuration location are provided; only verified paid orders may be used as events.
- The product catalogue in the current storefront is code-defined. The SQL products table is the planned editable source of truth.
- Razorpay and Supabase cannot be tested without your own credentials and deployed webhook URL.
- Legal pages are starter text and must be reviewed for your business and applicable Indian law.

Do not advertise this starter as a fully audited production commerce platform until the remaining items and live end-to-end tests are completed.

## 1. Requirements
- Node.js 20+
- Supabase project
- Razorpay account (start with Test Mode)
- Hosting such as Vercel

## 2. Install
```bash
npm install
cp .env.example .env.local
```
Fill Supabase URL, anon key, service-role key, Razorpay test key ID/secret, webhook secret, site URL and a random download token secret.

## 3. Database and storage
1. Open Supabase SQL Editor and run `supabase/schema.sql`.
2. In Supabase Storage confirm the private `digital-products` bucket exists.
3. Upload all files from `public/downloads/` to the bucket root, preserving filenames.
4. Create an admin user in Supabase Authentication.
5. Copy that user's UUID and insert it:
```sql
insert into public.admin_users(user_id) values ('YOUR_AUTH_USER_UUID');
```
6. Keep the Supabase service-role key server-side only.

## 4. Razorpay test setup
1. Create a Razorpay account and enable Test Mode.
2. Copy Test Key ID and Test Key Secret to `.env.local`.
3. Add webhook URL `https://YOUR_DOMAIN/api/razorpay/webhook`.
4. Subscribe to `payment.captured` and `payment.failed`.
5. Set the webhook signing secret as `RAZORPAY_WEBHOOK_SECRET`.
6. Test using Razorpay's official test payment instruments. Do not switch to Live Mode until webhook and payment reconciliation tests pass.

## 5. Run locally
```bash
npm run dev
```
Open http://localhost:3000. Admin: `/admin/login`.

## 6. Deploy
1. Push this project to a private GitHub repository.
2. Import into Vercel.
3. Add every `.env.example` variable in Vercel Project Settings.
4. Deploy and set `NEXT_PUBLIC_SITE_URL` to the production HTTPS URL.
5. Configure Razorpay webhook to the production webhook endpoint.
6. Run a test purchase and confirm order status changes to `paid` before enabling real downloads.

## 7. Security notes
- Never expose `SUPABASE_SERVICE_ROLE_KEY`, Razorpay secret, webhook secret or download token secret to browser code.
- Configure rate limiting and bot protection at the edge before public launch.
- Add monitoring, backups and payment reconciliation.
- The checkout's browser handler is not trusted: server verifies Razorpay signature. Webhook verification is separately implemented.
- Download tokens expire after 24 hours; the private storage URL is valid for 60 seconds.
- Refunds should be reconciled against Razorpay and the order database before changing access.
- Review RLS policies and run an independent security review before handling real customer data.

## 8. PDF catalogue
The PDFs are original educational starter resources. Replace or improve them through your content review before sale if you want a larger page count or brand-specific voice.
